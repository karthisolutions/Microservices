package com.boa.kyc.APIGateWayProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGateWayProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGateWayProjectApplication.class, args);
	}

}

